

<?php $__env->startSection('content'); ?>
    <!-- Start Page Title 
    ============================================= -->
    <div class="page-title-area shadow dark bg-fixed text-center text-light" style="background-image: url(/frontend/assets/img/2440x1578.png);">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <h1>Portfolio</h1>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title -->

    <!-- Start Breadcrumb 
    ============================================= -->
    <div class="breadcrumb-area bg-gray text-center">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
                        <li><a href="#">Pages</a></li>
                        <li class="active">Portfolio</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->

    <!-- Star Portfolio
    ============================================= -->
    <div class="portfolio-area default-padding">
        <div class="container">
            <div class="gallery-items-area">
                <div class="row">
                    <div class="col-md-12 gallery-content">
                        <div class="mix-item-menu text-center">
                            <button class="active" data-filter="*">All</button>
                            <?php $__currentLoopData = $portfolio_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            <button data-filter=".<?php echo e($category->title); ?>"><?php echo e($category->title); ?></button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                        <!-- End Mixitup Nav-->

                        <div class="row magnific-mix-gallery masonary">
                            <div id="portfolio-grid" class="gallery-items col-4">
                                <!-- Single Item -->
                                <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="pf-item <?php echo e($item->category_name); ?> capital">
                                    <div class="effect-box">
                                        <div class="thumb">
                                            <img src="<?php echo e(asset('Portfolios')); ?>/<?php echo e($item->image); ?>" alt="thumb" width="100%" height="200px">
                                        </div>
                                        <div class="info">
                                            <div class="left">
                                                <h4><a href="<?php echo e(URL::to('portfolio_singleview/'.$item->id)); ?>"><?php echo e($item->title); ?></a></h4> 
                                                <p><?php echo e($item->category_name); ?></p>
                                            </div>
                                            <div class="right">
                                                <a href="<?php echo e(asset('Portfolios/gallery')); ?>/<?php echo e($item->gallery_image); ?>" class="item popup-link"><i class="fa fa-plus"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- End Single Item -->
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Portfolio -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\laravel\admin_crm\resources\views/frontend/portfolio.blade.php ENDPATH**/ ?>