
<?php $__env->startSection('description','fvdv'); ?>
<?php $__env->startSection('title','ok'); ?>
<?php $__env->startSection('keywords','ddfvfdv'); ?>
<?php $__env->startSection('content'); ?>
<!-- Start Page Title 
    ============================================= -->
    <div class="page-title-area shadow dark bg-fixed text-center text-light" style="background-image: url('/frontend/assets/img/2440x1578.png');">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <h1>Our Services</h1>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title -->

    <!-- Start Breadcrumb 
    ============================================= -->
    <div class="breadcrumb-area bg-gray text-center">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
                        <li><a href="#">Pages</a></li>
                        <li class="active">Services</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->

    <!-- Start Our Services
        ============================================= -->
        <div class="modern-services-area bg-gray default-padding bottom-less">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="site-heading text-center">
                            <h4>Our services list</h4>
                            <h2>What we’re offering</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
    
                    <div class="col-md-12">
                        <div class="services-box text-center">
                            <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Single Item -->
                                <div class="single-item col-md-3 col-sm-6">
                                    <div class="item">
                                        <div class="thumb">
                                            <img src="<?php echo e(asset('Services')); ?>/<?php echo e($item->image); ?>" class="service_image" alt="Thumb" >
                                        </div>
                                        <div class="content">
                                            <h4><?php echo e($item->title); ?></h4>
                                            <div class="service_des">
                                                <?php echo $item->description; ?>

                                            </div>
                                            <a href="<?php echo e(URL::to('services_readmore/'.$item->id)); ?>">Read More <i class="ti-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div  class="col-md-12 text-center">
                        <?php echo $service->links('pagination::bootstrap-4'); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Our Services -->

    

    <!-- Star Testimonials Area
    ============================================= -->
    <div class="testimonials-area carousel-shadow default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="site-heading text-center">
                        <h4>Testimonials</h4>
                        <h2>What Client Says</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="testimonial-box">
                    <div class="row">
                        <div class="testimonial-items testimonial-carousel owl-carousel owl-theme">
                            <!-- Single Item -->
                            <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            
                            <div class="item">
                                <i class="fas fa-quote-right"></i>
                                <p>
                                    <?php echo $item->message; ?>

                                </p>
                                <div class="author">
                                    <div class="avatar">
                                        <img src="<?php echo e(asset('Testimonials')); ?>/<?php echo e($item->person_image); ?>" alt="Thumb">
                                    </div>
                                    <div class="info">
                                        <h4><?php echo e($item->name); ?></h4>
                                        <span><?php echo e($item->designation); ?></span>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- End Single Item -->
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Testimonials Area -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\laravel\admin_crm\resources\views/frontend/services.blade.php ENDPATH**/ ?>