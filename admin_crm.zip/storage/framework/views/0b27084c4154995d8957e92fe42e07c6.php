<div class="d-flex justify-content-end align-items-center" id="action">
    <a class="btn btn-danger btn-sm" onclick="deleteButton('<?php echo e($data->id); ?>')">
        <i class="far fa-trash-alt text-light"></i>
    </a>
</div><?php /**PATH C:\www\laravel\admin_crm\resources\views/admin/messages/action.blade.php ENDPATH**/ ?>