
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="https://common.olemiss.edu/_js/sweet-alert/sweet-alert.css">
    <link href="<?php echo e(asset('admin/assets/plugins/select/selectr.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="page-content-tab">
        <div class="container-fluid">
            <div class="row" style="justify-content: center">
                <div class="col-12">
                    <div class="card p-2 m-5">

                        <div class="card-header">
                            <div class="row align-items-left">
                                <div class="col">
                                    <h2 class="card-title-lg">Add Statistics</h2>
                                </div>
                                <!--end col-->
                            </div>
                            <!--end row-->
                        </div>

                        <div class="card-body">

                            <form class="form-horizontal auth-form my-4" method="post" id="submitForm" enctype="multipart/form-data"
                                action="<?php echo e(asset('admin/statistics/update')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                                <div class="form-group">
                                    <label for="example-text-input-lg" ></label>

                                </div>
                                <div class="form-group">
                                    <label for="example-text-input-lg" >Number</label>
                                    <div class="col-md-12">
                                        <input class="form-control mb-3" type="phone" name="number" value="<?php echo e($data->number); ?>"
                                            placeholder="Enter Number" id="example-text-input-lg" required>
                                    </div>
            
                                </div>
                                <div class="form-group">
                                    <label for="example-text-input-lg" >Title</label>
                                    <div class="col-md-12">
                                        <input class="form-control mb-3" type="text" name="title" value="<?php echo e($data->title); ?>"
                                            placeholder="Enter Title" id="example-text-input-lg" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="example-text-input-lg" >Description</label>
                                    <div class="col-md-12">
                                        <textarea class="ckeditor form-control" name="description"><?php echo e($data->description); ?></textarea>
                                    </div>
                                </div>

                                <br>
                                <center class="col-md-12">
                                    <button class="btn btn-primary mb-2 submitButton col-md-12" type="submit">Save <i
                                            class="fas fa-sign-in-alt ml-1"></i></button>
                                </center>
                            </form>
                            <?php if(count($errors) > 0): ?>
                                <small class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </small>
                            <?php endif; ?>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script src="https://common.olemiss.edu/_js/sweet-alert/sweet-alert.min.js"></script>
<script src="<?php echo e(asset('admin/assets/plugins/select/selectr.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/pages/forms-advanced.js')); ?>"></script>
<script src="//cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\laravel\admin_crm\resources\views/admin/statistics/statistics_edit.blade.php ENDPATH**/ ?>