
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="https://common.olemiss.edu/_js/sweet-alert/sweet-alert.css">
    <link href="<?php echo e(asset('admin/assets/plugins/select/selectr.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="page-content-tab">
            <div class="container-fluid">
                <div class="row" style="justify-content: center">
                    <div class="col-12">
                        <div class="card p-2 m-5">
                            <div class="card-header">
                                <div class="row align-items-left">
                                    <div class="col">
                                        <h2 class="card-title-lg">Edit Service Category</h2>
                                    </div>
                                    <!--end col-->
                                </div>
                                <!--end row-->
                            </div>

                            <div class="card-body">

                                <form class="form-horizontal auth-form my-4" method="post" id="submitForm" enctype="multipart/form-data"
                                    action="<?php echo e(asset('admin/blog/update')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                                    <div class="form-group">
                                        <label for="example-text-input-lg"
                                            >Title</label>
                                        <div class="col-md-12">
                                            <input class="form-control mb-3" type="text" name="title"
                                                value="<?php echo e($data->title); ?>" placeholder="Enter Title"
                                                id="example-text-input-lg">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-text-input-lg"
                                            >Description</label>
                                        <div class="col-sm-12 mb-3">
                                            <textarea class="ckeditor form-control" name="description"><?php echo e($data->description); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-text-input-lg"
                                            >Category</label>
                                        <div class="col-md-12 mb-3">
                                            <select id="default" class="form-control mb-3" name="category[]">
                                                <option value="">--Select--</option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value->id); ?>"
                                                        <?php if($data->category == $value->id): ?> selected <?php endif; ?>>
                                                        <?php echo e($value->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class=" form-group imgPreview">
                                        <div class="col-sm-2">
                                            <img src="<?php echo e(asset('Blogs')); ?>/<?php echo e($data->image); ?>" width="100%">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-text-input-lg"
                                            >Image</label>
                                        <div class="col-sm-12">
                                            <input class="form-control mb-3 file1" type="file" name="image"
                                                placeholder="Select Image" id="example-text-input-lg">
                                        </div>

                                    </div>
                                    <div class="form-group">
                                        <label for="example-text-input-lg" >Meta
                                            Title</label>
                                        <div class="col-md-12">
                                            <input class="form-control mb-3" type="text" name="meta_title"
                                                value="<?php echo e($data->meta_title); ?>" placeholder="Enter Meta Titile"
                                                id="example-text-input-lg">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-text-input-lg" >Meta
                                            Description</label>
                                        <div class="col-sm-12  mb-3">
                                            <textarea class="form-control" name="meta_description"><?php echo e($data->meta_description); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-text-input-lg" >Meta
                                            Keywords</label>
                                        <div class="col-md-12">
                                            <input class="form-control mb-3" type="text" name="meta_keyword"
                                                value="<?php echo e($data->meta_keyword); ?>" placeholder="Enter Meta Keywords"
                                                id="example-text-input-lg">
                                        </div>
                                    </div>
                            </div>
                            <div class="card-footer">
                                <center class="col-md-12">
                                    <button class="btn btn-primary mb-2 submitButton col-md-12" type="submit">Save <i
                                            class="fas fa-sign-in-alt ml-1"></i></button>
                                </center>
                            </div>
                            </form>
                            <?php if(count($errors) > 0): ?>
                                <small class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </small>
                            <?php endif; ?>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div>
        </div>
    </div>
    <!-- Javascript  -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script src="https://common.olemiss.edu/_js/sweet-alert/sweet-alert.min.js"></script>
<script src="//cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>
<script src="<?php echo e(asset('admin/assets/plugins/select/selectr.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/pages/forms-advanced.js')); ?>"></script>
<script>
    $('.file1').change(function(){
        const file = this.files[0];
        if (file){
            let reader = new FileReader();
            reader.onload = function(event){
            console.log(event.target.result);
            $('.imgPreview img').attr('src', event.target.result);
            $('.imgPreview').show();
            }
            reader.readAsDataURL(file);
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\laravel\admin_crm\resources\views/admin/blog/blog_edit.blade.php ENDPATH**/ ?>