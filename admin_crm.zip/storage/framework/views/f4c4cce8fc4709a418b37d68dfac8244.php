<?php if(Session::has('success')): ?>
    <script>
    $.toast({
        heading: 'Success',
        text: '<?php echo e(Session::get('success')); ?>',
        showHideTransition: 'slide',
        icon: 'success',
        position: 'top-right',
        stack: false
    })
    </script>
<?php endif; ?>
    
<?php if(Session::has('error')): ?>
    <script>
    $.toast({
        heading: 'Error',
        text: '<?php echo e(Session::get('error')); ?>',
        showHideTransition: 'slide',
        icon: 'error',
        position: 'top-right',
        stack: false
    })
    </script>
<?php endif; ?><?php /**PATH C:\www\laravel\admin_crm\resources\views/admin/main/script.blade.php ENDPATH**/ ?>