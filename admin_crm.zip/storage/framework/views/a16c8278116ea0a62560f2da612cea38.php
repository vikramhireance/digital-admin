
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="https://common.olemiss.edu/_js/sweet-alert/sweet-alert.css">
<link href="<?php echo e(asset('admin/assets/plugins/select/selectr.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="page-content-tab">
        <div class="container-fluid">
            <div class="row" style="justify-content: center">
                <div class="col-12">
                    <div class="card p-2 m-5">

                        <div class="card-header">
                            <div class="row align-items-left">
                                <div class="col">
                                    <h2 class="card-name-lg">Edit Team</h2>
                                </div>
                                <!--end col-->
                            </div>
                            <!--end row-->
                        </div>

                        <div class="card-body">
                            <form class="form-horizontal auth-form my-4" method="post" id="submitForm" enctype="multipart/form-data"
                                action="<?php echo e(asset('/admin/team/update')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                                <div class="form-group">
                                    <label for="example-text-input-lg">Name</label>
                                    <div class="col-md-12">
                                        <input class="form-control mb-3" type="text" name="name" value="<?php echo e($data->name); ?>" required
                                            placeholder="Enter Name" id="example-text-input-lg">
                                    </div>                          
                                </div>
                                <div class="form-group">
                                    <label for="example-text-input-lg">Designation</label>
                                    <div class="col-md-12">
                                        <input class="form-control mb-3" type="text" name="designation" value="<?php echo e($data->designation); ?>" required
                                            placeholder="Enter Designation" id="example-text-input-lg">
                                    </div>
                                </div>
                                <div class="form-group imgPreview">
                                    <div class="col-sm-3">
                                        <img src="<?php echo e(asset('Upload/Teams')); ?>/<?php echo e($data->person_image); ?>" width="100%">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="example-text-input-lg">Person Image</label>
                                    <div class="col-sm-12">
                                        <input class="form-control mb-3 file1" type="file" name="person_image"
                                            placeholder="Select Image" id="example-text-input-lg">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="example-t00ext-input-lg">Description</label>
                                    <div class="col-md-12 mb-3">
                                        <textarea class="ckeditor form-control" name="description"><?php echo e($data->description); ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="example-t00ext-input-lg">Facebook URL</label>
                                    <div class="col-md-12">
                                        <input class="form-control mb-3" type="text" name="facebook_URL" value="<?php echo e($data->facebook_URL); ?>" required
                                            placeholder="Enter Facebook URL" id="example-text-input-lg">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="example-t00ext-input-lg">Instagram URL</label>
                                    <div class="col-md-12">
                                        <input class="form-control mb-3" type="text" name="instagram_URL" value="<?php echo e($data->instagram_URL); ?>" required
                                            placeholder="Enter Instagram URL" id="example-text-input-lg">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="example-t00ext-input-lg">Linkedin URL</label>
                                    <div class="col-md-12">
                                        <input class="form-control mb-3" type="text" name="linkedin_URL" value="<?php echo e($data->linkedin_URL); ?>" required
                                            placeholder="Enter Linkedin URL" id="example-text-input-lg">
                                    </div>
                                </div>
                        </div>
                        <div class="card-footer">
                            <center class="col-md-12">
                                <button class="btn btn-primary mb-2 submitButton col-md-12" type="submit">Save <i
                                        class="fas fa-sign-in-alt ml-1"></i></button>
                            </center>
                        </div>
                        </form>
                        <?php if(count($errors) > 0): ?>
                            <small class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </small>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script src="https://common.olemiss.edu/_js/sweet-alert/sweet-alert.min.js"></script>
<script src="//cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>
<script src="<?php echo e(asset('/admin/assets/plugins/select/selectr.min.js')); ?>"></script>
<script src="<?php echo e(asset('/admin/assets/pages/forms-advanced.js')); ?>"></script>
<script>
    $('.file1').change(function(){
        const file = this.files[0];
        if (file){
            let reader = new FileReader();
            reader.onload = function(event){
            console.log(event.target.result);
            $('.imgPreview img').attr('src', event.target.result);
            }
            reader.readAsDataURL(file);
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\laravel\admin_crm\resources\views/admin/team/team_edit.blade.php ENDPATH**/ ?>