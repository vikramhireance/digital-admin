
<?php $__env->startSection('description',$service->meta_description); ?>
<?php $__env->startSection('title',$service->meta_title); ?>
<?php $__env->startSection('keywords',$service->meta_keyword); ?>
<?php $__env->startSection('content'); ?>
     <!-- Start Page Title 
    ============================================= -->
    <div class="page-title-area shadow dark bg-fixed text-center text-light" style="background-image: url(/frontend/assets/img/2440x1578.png);">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <h1>Services Single</h1>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title -->

    <!-- Start Breadcrumb 
    ============================================= -->
    <div class="breadcrumb-area bg-gray text-center">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
                        <li><a href="#">Services</a></li>
                        <li class="active">Single</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->

    <!-- Start 404 
    ============================================= -->
    <div class="gallery-single-area default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="thumb">
                        <img src="<?php echo e(asset('Services')); ?>/<?php echo e($service->image); ?>" alt="Thumb">
                    </div>
                    <div class="info">
                        <h2><?php echo e($service->title); ?></h2>
                        <ul class="project-info">
                            <li><strong>Category:</strong> 
                                <?php $__currentLoopData = $service->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($item->title); ?>

                                    <?php if($key+1 != count($service->category)): ?>,<?php endif; ?>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </li>
                            <li><strong>Date:</strong> <?php echo e($service->created_at->format('d M y')); ?></li>
                            
                        </ul>
                        <p>
                           <?php echo $service->description; ?> 
                        </p>
                       
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End 404 -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\laravel\admin_crm\resources\views/frontend/services_readmore.blade.php ENDPATH**/ ?>