<div class="d-flex justify-content-end align-items-center" id="action">
    <a href="<?php echo e(asset('admin/team/edit/'.$data->id)); ?>" class="btn btn-success btn-sm mr-2">
        <i class="far fa-edit text-light"></i>
    </a>
    <a class="btn btn-danger btn-sm" onclick="deleteButton('<?php echo e($data->id); ?>')">
        <i class="far fa-trash-alt text-light"></i>
    </a>
</div><?php /**PATH C:\www\laravel\admin_crm\resources\views/admin/team/action.blade.php ENDPATH**/ ?>