<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class General_Settings extends Model
{
    protected $table = 'general_settings';
    use HasFactory;
}
