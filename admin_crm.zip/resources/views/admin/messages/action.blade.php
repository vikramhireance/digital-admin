<div class="d-flex justify-content-end align-items-center" id="action">
    <a class="btn btn-danger btn-sm" onclick="deleteButton('{{$data->id}}')">
        <i class="far fa-trash-alt text-light"></i>
    </a>
</div>